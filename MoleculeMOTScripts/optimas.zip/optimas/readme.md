optimise the slowing parameters of CaF MOT using a 
differential evolution algorithm